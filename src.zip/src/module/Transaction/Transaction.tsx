export const Transaction = () => {
  return <h1>Transaction</h1>;
};
