export const Report = () => {
  return <h1>Report</h1>;
};
