export const CompanyMaster = () => {
  return <h1>CompanyMaster</h1>;
};
