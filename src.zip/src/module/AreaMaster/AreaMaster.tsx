export const AreaMaster = () => {
  return <h1>AreaMaster</h1>;
};
