import { Button, Card, Group, SimpleGrid, TextInput } from '@mantine/core';
import { useForm } from '@mantine/form';

interface AddPartyData {
  partyCode: string;
  name: string;
  category: string;
  address: string;
  city: string;
  pincode: number;
  district: string;
  state: string;
  contactPerson: string;
  phoneNumber: '';
  email: string;
  GSTIN: string;
  PAN: string;
  creditLimit: number;
  creditPeriod: number;
  creditInvoice: number;
}

export const AddParty = () => {
  const form = useForm({
    initialValues: {
      partyCode: '',
      name: '',
      category: '',
      address: '',
      city: '',
      pincode: '',
      district: '',
      state: '',
      contactPerson: '',
      phoneNumber: '',
      email: '',
      GSTIN: '',
      PAN: '',
      creditLimit: '',
      creditPeriod: '',
      creditInvoice: '',
    },

    validate: {
      email: (value) => (/^\S+@\S+$/.test(value) ? null : 'Invalid email'),
    },
  });

  const handleSubmit = (values: any) => {
    console.log(values);
  };

  return (
    <Card withBorder radius="sm">
      <form onSubmit={form.onSubmit((values) => handleSubmit(values))}>
        <SimpleGrid
          cols={2}
          breakpoints={[{ maxWidth: 600, cols: 1, spacing: 'sm' }]}
        >
          <TextInput
            type="number"
            label="Party Code"
            placeholder="10001"
            {...form.getInputProps('partyCode')}
          />
          <TextInput
            label="Name"
            placeholder="Party Name"
            {...form.getInputProps('name')}
          />
          <TextInput
            label="Category"
            placeholder="Category"
            {...form.getInputProps('category')}
          />

          <TextInput
            label="Address"
            placeholder="Address"
            {...form.getInputProps('address')}
          />
          <TextInput
            label="City"
            placeholder="City"
            {...form.getInputProps('city')}
          />
          <TextInput
            type="number"
            label="Pin Code"
            placeholder="Pin Code"
            {...form.getInputProps('pincode')}
          />

          <TextInput
            label="District"
            placeholder="District"
            {...form.getInputProps('district')}
          />
          <TextInput
            label="State"
            placeholder="State"
            {...form.getInputProps('state')}
          />

          <TextInput
            label="Contact Person"
            placeholder="Conatct Person"
            {...form.getInputProps('contactPerson')}
          />
          <TextInput
            label="Phone Number"
            placeholder="Phone Number"
            {...form.getInputProps('phoneNumber')}
          />
          <TextInput
            label="Your Email"
            placeholder="Your Email"
            {...form.getInputProps('email')}
          />

          <TextInput
            label="GSTIN"
            placeholder="GSTIN"
            {...form.getInputProps('GSTIN')}
          />
          <TextInput
            label="PAN"
            placeholder="PAN"
            {...form.getInputProps('PAN')}
          />

          <TextInput
            type="number"
            label="Credit Limit"
            placeholder="Credit Limit"
            {...form.getInputProps('creditLimit')}
          />
          <TextInput
            type="number"
            label="Credit Period"
            placeholder="Credit Period"
            {...form.getInputProps('creditPeriod')}
          />
          <TextInput
            type="number"
            label="Credit Invoices"
            placeholder="Credit Invoices"
            {...form.getInputProps('creditInvoice')}
          />
        </SimpleGrid>
        <Button
          type="submit"
          variant="outline"
          color="green"
          sx={(theme) => ({ marginTop: '18px', display: 'flex', flex: '1' })}
        >
          Submit
        </Button>
      </form>
    </Card>
  );
};
