import { Box } from '@mantine/core';
import { Table } from './components';

export const PartyMaster = () => {
  return (
    <Box>
      <Table />
    </Box>
  );
};
